'''pyBEL1D is a package that computes the posterior model space for a given 
experiment (geophysical in the design) and a given prior model space.
'''